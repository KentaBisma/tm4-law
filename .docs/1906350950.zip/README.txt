Muhammad Kenta Bisma Dewa Brata
1906350950

Links:

GitHub: https://github.com/KentaBisma/tm4-law

Analisa:

Service idempoten berbantuan cache mampu bertahan jauh lebih lama secara signifikan dibandingkan dengan tanpa cache.
Dengan ini, kita dapat tarik kesimpulan bahwa caching mampu meningkatkan performa dari microservice